import React from "react";
import Header from "../Component/Header";
import HeroBanner from "../Component/HeroBanner";
import CallToAction from "../Component/CallToAction";
import Product from "../Component/Product";
import DairyBreadAndEggs from "../Component/DairyBreadAndEggs";
import RollingPaperAndTobacco from "../Component/RollingPaperAndTobacco";
import SnacksAndMunchies from "../Component/SnacksAndMunchies";
import MobileFooterBanner from "../Mobile Component/MobileFooterBanner";
import HouseholdCleaningEssentials from "../Mobile Component/HouseholdCleaningEssentials"
import Footer from "../Component/Footer";
import SocialLinks from "../Component/SocialLinks";
import ColdDrinksAndJuices from "../Component/ColdDrinksAndJucies";
import CandiesAndGums from "../Component/CandiesAndGums";
import MouthFresheners from "../Component/MouthFresheners";
import Hookah from "../Component/Hookah";

export default function Home() {
     return (
          <>
               <Header />
               <HeroBanner />
               <CallToAction />
               <Product />
               <DairyBreadAndEggs />
               <RollingPaperAndTobacco />
               <SnacksAndMunchies />
               <Hookah />
               <MouthFresheners />
               <ColdDrinksAndJuices />
               <CandiesAndGums />
               <HouseholdCleaningEssentials />
               <MobileFooterBanner />
               <Footer />
               <SocialLinks />
          </>
     )
}