import React, { useContext, useState } from "react";
import { NavLink } from "react-router";
import { CartContext } from "../Context/Cart";

export default function Cart() {
     const { cart, AddToCart, RemoveFromCart } = useContext(CartContext);

     const SP = cart.reduce((sum, item) => sum + item.SP * item.Quantity, 0);
     const MRP = cart.reduce((sum, item) => sum + (item.MRP || item.SP) * item.Quantity, 0);
     const TotalSavings = MRP - SP;
     const DeliveryCharge = 25;
     const HandlingCharge = 2;
     const GrandTotal = SP + DeliveryCharge + HandlingCharge;

     return (
          <div className="w-full h-screen bg-[rgb(245,247,253)]">
               <div className="w-full h-[60px] bg-white sticky top-0 z-25000 flex items-center justify-between p-[18px]">
                    <div className="text-base font-bold text-[rgb(31,31,31)] leading-5">My Cart</div>

                    <NavLink to="/">
                         <div className="font-bold cursor-pointer flex items-center justify-center">
                              <svg xmlns="http://www.w3.org/2000/svg" height="21px" viewBox="0 -960 960 960" width="21px" fill="#1F1F1F">
                                   <path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z" />
                              </svg>
                         </div>
                    </NavLink>
               </div>

               <div className="w-full px-3">
                    {
                         cart.length > 0 ? (
                              <>
                                   {/* Delivery Time */}
                                   <div className="bg-white rounded-t-[15px] mt-3 flex items-start py-3">
                                        <div className="w-[48px] h-[48px] ml-3 flex items-center justify-center">
                                             <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=180/assets/eta-icons/15-mins-filled.png" alt="Delivery Time" loading="lazy" className="w-full h-full object-fit" />
                                        </div>

                                        <div className="flex items-start justify-center flex-col grow pl-4">
                                             <div className="text-[15px] font-bold text-black pb-1 flex items-center justify-center">Delivery in 11 minutes</div>

                                             <div className="text-xs text-[rgb(102,102,102)] flex items-center justify-center">Shipment of {cart.length} item</div>
                                        </div>
                                   </div>

                                   {/* Product */}
                                   {
                                        cart.map((item) => (
                                             <div key={item.ID} className="bg-white rounded-b-[15px] flex items-center">
                                                  <div className="w-[72px] h-[72px] border border-[rgb(242,242,242)] rounded-lg overflow-hidden flex items-center justify-center my-3 ml-3">
                                                       <img src={item.src} alt={item.title} loading="lazy" className="object-cover" />
                                                  </div>

                                                  <div className="flex items-center justify-between grow my-[9px] mx-3">
                                                       <div className="flex items-start justify-center flex-col">
                                                            <div className="w-[121px] text-xs font-normal text-[rgb(28,28,28)] leading-4 line-clamp-2">{item.title}</div>

                                                            <div className="w-[120px] text-xs font-normal text-[rgb(105,105,105)] py-1">{item.weight}</div>

                                                            <div className="flex items-center justify-center">
                                                                 <div className="text-xs font-bold text-[rgb(31,31,31)]">₹{item.SP}</div>
                                                                 <div className="text-xs font-normal text-[rgb(102,102,102)] ml-2 line-through">{item.MRP}</div>
                                                            </div>
                                                       </div>

                                                       <div className="w-[66px] h-[31px] bg-[rgb(49,134,22)] text-[13px] font-semibold text-white border border-[rgb(49,134,22)] rounded-md flex items-center justify-between gap-1.5 cursor-pointer">
                                                            <button onClick={() => RemoveFromCart(item.ID)} className="w-fit h-full text-[13px] font-semibold text-white flex items-center justify-center ml-2 cursor-pointer">-</button>
                                                            <span>{item.Quantity}</span>
                                                            <button onClick={() => AddToCart(item)} className="w-fit h-full text-[13px] font-semibold text-white flex items-center justify-center mr-2 cursor-pointer">+</button>
                                                       </div>
                                                  </div>
                                             </div>
                                        )
                                        )
                                   }

                                   {/* Bill Details */}
                                   <div className="bg-white rounded-t-[15px] mt-6">
                                        <div className="text-[15px] font-extrabold text-[rgb(54,54,54)] py-2 px-3 flex">Bill Details</div>

                                        {/* Items Total */}
                                        <div className="text-[15px] font-medium text-[rgb(54,54,54)] pb-2 px-3 flex items-center justify-between">
                                             <div className="flex items-center justify-center">
                                                  <div className="mr-1.5">
                                                       <svg xmlns="http://www.w3.org/2000/svg" height="12px" viewBox="0 -960 960 960" width="12px" fill="#000000">
                                                            <path d="M120-80v-800l60 60 60-60 60 60 60-60 60 60 60-60 60 60 60-60 60 60 60-60 60 60 60-60v800l-60-60-60 60-60-60-60 60-60-60-60 60-60-60-60 60-60-60-60 60-60-60-60 60Zm120-200h480v-80H240v80Zm0-160h480v-80H240v80Zm0-160h480v-80H240v80Z" />
                                                       </svg>
                                                  </div>

                                                  <div className="text-xs font-medium text-[rgb(54,54,54)]">Items total</div>

                                                  <div className="text-[9px] font-semibold text-[rgb(37,111,239)] bg-[rgb(237,244,255)] py-0.5 px-1 rounded-sm ml-1.5 overflow-hidden">Saved ₹{TotalSavings}</div>
                                             </div>

                                             <div className="flex items-center justify-center gap-1">
                                                  <span className="text-[13px] font-medium text-[rgb(105,105,105)] line-through">₹{MRP}</span>
                                                  <span className="text-[13px] font-medium text-[#363636]">₹{SP}</span>
                                             </div>
                                        </div>

                                        {/* Delivery Charge */}
                                        <div className="text-[15px] font-medium text-[rgb(54,54,54)] pb-2 px-3 flex items-center justify-between">
                                             <div className="flex items-center justify-center">
                                                  <div className="mr-1.5">
                                                       <svg xmlns="http://www.w3.org/2000/svg" height="12px" viewBox="0 -960 960 960" width="12px" fill="#000000">
                                                            <path d="M195-235q-35-35-35-85H80v-120q0-66 47-113t113-47h160v200h140l140-174v-106H560v-80h120q33 0 56.5 23.5T760-680v134L580-320H400q0 50-35 85t-85 35q-50 0-85-35Zm113.5-56.5Q320-303 320-320h-80q0 17 11.5 28.5T280-280q17 0 28.5-11.5ZM200-640v-80h200v80H200Zm475 405q-35-35-35-85t35-85q35-35 85-35t85 35q35 35 35 85t-35 85q-35 35-85 35t-85-35Zm113.5-56.5Q800-303 800-320t-11.5-28.5Q777-360 760-360t-28.5 11.5Q720-337 720-320t11.5 28.5Q743-280 760-280t28.5-11.5Z" />
                                                       </svg>
                                                  </div>

                                                  <div className="text-xs font-medium text-[rgb(54,54,54)]">Delivery charge</div>
                                             </div>

                                             <div className="flex items-center justify-center">
                                                  <span className="text-[13px] font-medium text-[#363636]">₹{DeliveryCharge}</span>
                                             </div>
                                        </div>

                                        {/* Handling Charge */}
                                        <div className="text-[15px] font-medium text-[rgb(54,54,54)] pb-2 px-3 flex items-center justify-between">
                                             <div className="flex items-center justify-center">
                                                  <div className="mr-1.5">
                                                       <svg xmlns="http://www.w3.org/2000/svg" height="12px" viewBox="0 -960 960 960" width="12px" fill="#000000">
                                                            <path d="M240-80q-33 0-56.5-23.5T160-160v-480q0-33 23.5-56.5T240-720h80q0-66 47-113t113-47q66 0 113 47t47 113h80q33 0 56.5 23.5T800-640v480q0 33-23.5 56.5T720-80H240Zm160-640h160q0-33-23.5-56.5T480-800q-33 0-56.5 23.5T400-720Zm228.5 188.5Q640-543 640-560v-80h-80v80q0 17 11.5 28.5T600-520q17 0 28.5-11.5Zm-240 0Q400-543 400-560v-80h-80v80q0 17 11.5 28.5T360-520q17 0 28.5-11.5Z" />
                                                       </svg>
                                                  </div>

                                                  <div className="text-xs font-medium text-[rgb(54,54,54)]">Handling charge</div>
                                             </div>

                                             <div className="flex items-center justify-center">
                                                  <span className="text-[13px] font-medium text-[#363636]">₹{HandlingCharge}</span>
                                             </div>
                                        </div>

                                        {/* Grand Total */}
                                        <div className="pt-1 px-3 pb-3 flex items-center justify-between">
                                             <div className="text-[13px] font-bold text-[rgb(28,28,28)]">Grand Total</div>
                                             <div className="text-[15px] font-semibold text-[#1F1F1F]">₹{GrandTotal}</div>
                                        </div>
                                   </div>

                                   {/* Cancellation Policy */}
                                   <div className="bg-white rounded-[15px] px-4 my-3">
                                        <div className="text-[15px] font-bold text-black pt-3 pb-1">Cancellation Policy</div>
                                        <div className="text-xs font-medium text-[rgb(130,130,130)] pb-3">Orders cannot be cancelled once packed for delivery. In case of unexpected delays, a refund will be provided, if applicable.</div>
                                   </div>
                              </>
                         ) : (
                              < div className="bg-white rounded-[15px] mt-3 p-4 flex items-center justify-center flex-col">
                                   <div className="w-[144px] h-[144px] mt-1 mb-4">
                                        <img src="https://cdn.grofers.com/assets/ui/empty_states/emp_empty_cart.png" alt="Empty Cart" className="w-full h-full object-cover" />
                                   </div>

                                   <div className="text-lg text-black mb-2 text-center">You don't have any items in your cart</div>

                                   <div className="text-sm text-[rgb(153,153,153)] mb-5">Your favourite items are just a click away</div>

                                   <NavLink to="/">
                                        <button className="text-xs min-h-9 text-white whitespace-nowrap bg-[rgb(12,131,31)] rounded-lg flex items-center justify-center px-[25px] mb-3 cursor-pointer capitalize">Start Shopping</button>
                                   </NavLink>
                              </div>
                         )
                    }
               </div>
          </div >
     )
}