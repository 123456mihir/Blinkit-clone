import React, { useContext, useState } from "react";
import { CartContext } from "../Context/Cart";

export default function ProductCard(props) {
     const { cart, AddToCart, RemoveFromCart } = useContext(CartContext);

     const Cart = cart.find(Item => Item.ID === props.ID);
     const Count = Cart ? Cart.Quantity : 0;

     return (
          <div className="w-[179px] bg-white border-[0.5px] border-[rgb(232,232,232)] shadow-[2px_2px_8px_0px_rgba(0,0,0,0.04)] rounded-lg pb-3 relative flex items-start flex-col shrink-0 gap-0.5 cursor-pointer snap-start">
               {
                    props.Discount && (
                         <div className="absolute top-0 left-3 flex items-center z-10">
                              <svg width="29" height="28" viewBox="0 0 29 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M28.9499 0C28.3999 0 27.9361 1.44696 27.9361 2.60412V27.9718L24.5708 25.9718L21.2055 27.9718L17.8402 25.9718L14.4749 27.9718L11.1096 25.9718L7.74436 27.9718L4.37907 25.9718L1.01378 27.9718V2.6037C1.01378 1.44655 0.549931 0 0 0H28.9499Z" fill="#538CEE"></path>
                              </svg>

                              <div className="text-[9px] font-extrabold text-white text-center absolute flex items-center justify-center z-25">{props.Discount} OFF</div>
                         </div>
                    )
               }

               <div className="w-full h-full rounded-xl flex items-center justify-center overflow-hidden">
                    <img src={props.src} alt="" width={140} height={140} loading="lazy" className="object-fill" />
               </div>

               <div className="w-full px-3">
                    <div className="w-[90%] h-[15px] flex items-center justify-start mb-[7px] overflow-hidden">
                         <div className="bg-[rgb(248,248,248)] rounded-sm px-1 flex items-center justify-center gap-0.5">
                              <div className="w-[11px] h-full flex items-center justify-center aspect-square overflow-hidden">
                                   <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=90/assets/eta-icons/15-mins.png" className="w-full h-full" />
                              </div>

                              <div className="text-[9px] font-bold text-[rgb(54,54,54)] uppercase flex items-center justify-center">{props.DeliveryTime}</div>
                         </div>
                    </div>

                    <div className="w-full h-[36px] text-[13px] font-semibold text-[rgb(31,31,31)] leading-[18px] mb-1.5 line-clamp-2">{props.title}</div>

                    <div className="w-full h-[26px] flex items-center mb-2">
                         <span className="text-xs text-[#666666]">{props.weight} {props.unit}</span>
                    </div>

                    <div className="w-full flex items-center justify-between">
                         <div className="flex items-center justify-center flex-col">
                              <div className="text-xs font-semibold text-[rgb(31,31,31)]">₹{props.SP}</div>
                              {
                                   props.MRP && <div className="text-xs font-normal text-[rgb(130,130,130)] line-through">₹{props.MRP}</div>
                              }
                         </div>

                         {
                              Count == 0 ? (
                                   <button onClick={() => AddToCart(props)} className="w-[66px] h-[31px] bg-[rgb(247,255,249)] text-[13px] font-semibold text-[rgb(49,134,22)] border border-[rgb(49,134,22)] rounded-md flex items-center justify-center cursor-pointer">ADD</button>) : (
                                   <div className="w-[66px] h-[31px] bg-[rgb(49,134,22)] text-[13px] font-semibold text-white border border-[rgb(49,134,22)] rounded-md flex items-center justify-between gap-1.5 cursor-pointer">
                                        <button onClick={() => RemoveFromCart(props.ID)} className="w-fit h-full text-[13px] font-semibold text-white flex items-center justify-center ml-2 cursor-pointer">-</button>
                                        <span>{Count}</span>
                                        <button onClick={() => AddToCart(props)} className="w-fit h-full text-[13px] font-semibold text-white flex items-center justify-center mr-2 cursor-pointer">+</button>
                                   </div>
                              )
                         }
                    </div>
               </div>
          </div>
     )
}