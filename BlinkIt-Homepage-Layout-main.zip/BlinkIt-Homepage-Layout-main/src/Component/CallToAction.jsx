import React from "react";
import CallToActionData from "../Data/CallToAction";

export default function CallToAction() {
     return (
          <div width={335.40000000000003} className="max-w-[1280px] mx-auto hidden min-[1021px]:flex items-center gap-x-5 p-4">
               {
                    CallToActionData.map((Category) => (
                         <div key={Category.ID} className="cursor-pointer">
                              <img src={Category.Source} alt={Category.alt} width={335.40000000000003} height={195} loading="lazy" className="rounded-2xl object-fill" />
                         </div>
                    ))
               }
          </div>
     )
}