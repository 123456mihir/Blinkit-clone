import React from "react";

export default function Login({ onClick }) {
     return (
          <div className="w-full h-full fixed top-0 left-0 right-0 bottom-0 bg-[rgba(0,0,0,0.7)] flex items-center justify-center z-2500">
               <div className="w-[570px] text-center bg-white rounded-2xl relative pt-5 overflow-hidden">
                    <button onClick={onClick} className="text-xl py-2 px-2.5 absolute top-[15px] left-[15px] cursor-pointer">
                         <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#1F1F1F">
                              <path d="M400-240 160-480l240-240 56 58-142 142h486v80H314l142 142-56 58Z" />
                         </svg>
                    </button>

                    <div className="flex items-center justify-center flex-col">
                         <div className="w-[64px] h-[64px] flex items-center justify-center opacity-100 transition-opacity duration-250">
                              <img src="https://cdn.grofers.com/layout-engine/2023-11/app_logo.svg" alt="Blinkit" loading="lazy" width={64} height={64} className="object-cover" />
                         </div>

                         <div className="flex items-center justify-center flex-col">
                              <h2 className="text-2xl font-extrabold text-[#333333] text-center">India's last minute app</h2>
                              <h3 className="text-base font-extrabold text-[#333333] text-center">Log in or Sign up</h3>
                         </div>

                         <form className="flex items-center justify-center flex-col mt-5">
                              <div className="w-[300px] flex items-center gap-2 border rounded-xl px-5 py-[15px]">
                                   <span className="text-sm font-semibold text-[#666666]">+91</span>
                                   <input type="tel" maxLength="10" placeholder="Enter mobile number" className="flex-1 text-sm font-semibold outline-none border-none bg-transparent" />
                              </div>

                              <button type="button" className="w-[300px] min-h-[50px] bg-[rgb(156,156,156)] text-sm font-medium text-white text-center mt-[18px] p-4 rounded-xl">Continue</button>
                         </form>

                         <div className="w-full bg-[rgb(251,251,251)] text-center py-3">
                              <span className="text-xs text-[#666666]">By continuing, you agree to our </span>
                              <a href="/terms" target="_blank" className="text-xs text-[#666666]"> Terms of service & Privacy policy</a>
                         </div>
                    </div>
               </div>
          </div>
     )
}