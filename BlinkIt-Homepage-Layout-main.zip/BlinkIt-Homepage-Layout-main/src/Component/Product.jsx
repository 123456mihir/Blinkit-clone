import React from "react";
import Products from "../Data/Products"

export default function Product() {
     return (
          <div className="max-w-[1280px] grid grid-cols-2 min-[640px]:grid-cols-4 min-[1021px]:grid-cols-10 mx-auto">
               {
                    Products.map((Product) => (
                         <div key={Product.ID} className="w-[128px] h-[188.235px] cursor-pointer mx-auto">
                              <img src={Product.Source} alt={Product.alt} width={128} height={188.23529411764704} loading="lazy" className="object-fill"/>
                         </div>
                    ))
               }
          </div>
     )
}