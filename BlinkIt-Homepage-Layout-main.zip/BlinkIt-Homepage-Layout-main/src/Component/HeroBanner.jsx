import React from "react";

export default function HeroBanner() {
     return (
          <div height={271.76220806794055} className="max-w-[1280px] mx-auto hidden min-[1021px]:flex cursor-pointer">
               <img src="https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=2160/layout-engine/2026-01/Frame-1437256605-1_0.png" width={1280} height={271.76220806794055} loading="eager" className="object-fill"/>
          </div>
     )
}