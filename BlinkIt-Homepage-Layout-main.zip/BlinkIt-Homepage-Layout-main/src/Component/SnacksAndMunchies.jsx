import React, { useEffect, useState } from "react";
import Products from "../Data/SnacksAndMunchies";
import ProductCard from "./ProductCard";

export default function SnacksAndMunchies() {
     const CardWidth = 179;
     const Gap = 20;
     const [index, setIndex] = useState(0);
     const [item, setItem] = useState(6)

     useEffect(
          () => {
               const Resize = () => {
                    if (window.innerWidth < 425) {
                         setItem(1);
                    } else if (window.innerWidth < 768) {
                         setItem(2);
                    } else if (window.innerWidth < 1020) {
                         setItem(4);
                    } else {
                         setItem(6);
                    }
               }

               Resize();

               window.addEventListener("resize", Resize);

               return () => window.removeEventListener("resize", Resize);;
          }, []
     );

     const MaximumIndex = Math.max(Products.length - item, 0);

     const Next = () => {
          setIndex(
               (previous) => {
                    return Math.min(previous + item, MaximumIndex);
               }
          )
     };

     const Previous = () => {
          setIndex(
               (previous) => {
                    return Math.max(previous - item, 0);
               }
          );
     };

     return (
          <div className="max-w-[1280px] mx-auto">
               <div className="bg-white flex items-center justify-between mx-3">
                    <h2 className="text-2xl font-semibold text-[rgb(28,28,28)] leading-8 flex items-center justify-center py-4">Snacks & Munchies</h2>
                    <a href="/" className="text-xl text-[rgb(12,131,31)] leading-8 flex items-center justify-center cursor-pointer">see all</a>
               </div>

               <div className="bg-white flex items-center  relative">
                    <div className="w-[34px] h-full opacity-100 flex items-center absolute left-0">
                         {
                              index > 0 && (
                                   <button onClick={Previous} className="w-[34px] h-[34px] bg-white hover:bg-[rgb(248,248,248)] active:bg-[rgb(232,232,232)] border-4 border-transparent rounded-full flex items-center justify-center z-25 cursor-pointer" style={{ boxShadow: "rgba(0, 0, 0, 0.2)0px 3px 5px -1px, rgba(0, 0, 0, 0.14) 0px 6px 10px 0px, rgba(0, 0, 0, 0.12) 0px 1px 18px 0px" }}>
                                        <svg xmlns="http://www.w3.org/2000/svg" height="25px" viewBox="0 -960 960 960" width="25px" fill="#1C1C1C">
                                             <path d="M560-240 320-480l240-240 56 56-184 184 184 184-56 56Z" />
                                        </svg>
                                   </button>
                              )
                         }
                    </div>

                    <div className="overflow-hidden">
                         <div className="w-full flex items-center flex-row gap-x-[20px] transition-transform duration-500 ease-in-out mx-3 pb-5" style={{ transform: `translateX(-${index * (CardWidth + Gap)}px)` }}>
                              {
                                   Products.map((Product) => (
                                        <ProductCard key={Product.ID} ID={Product.ID} src={Product.src} DeliveryTime={Product.DeliveryTime} title={Product.title} weight={Product.weight} MRP={Product.MRP} SP={Product.SP} Discount={Product.Discount} />
                                   ))
                              }
                         </div>
                    </div>

                    <div className="w-[34px] h-full opacity-100 flex items-center absolute right-0">
                         <button onClick={Next} className="w-[34px] h-[34px] bg-white hover:bg-[rgb(248,248,248)] active:bg-[rgb(232,232,232)] border-4 border-transparent rounded-full flex items-center justify-center z-25 cursor-pointer" style={{ boxShadow: "rgba(0, 0, 0, 0.2)0px 3px 5px -1px, rgba(0, 0, 0, 0.14) 0px 6px 10px 0px, rgba(0, 0, 0, 0.12) 0px 1px 18px 0px" }}>
                              <svg xmlns="http://www.w3.org/2000/svg" height="25px" viewBox="0 -960 960 960" width="25px" fill="#1C1C1C">
                                   <path d="M504-480 320-664l56-56 240 240-240 240-56-56 184-184Z" />
                              </svg>
                         </button>
                    </div>
               </div>
          </div >
     );
}