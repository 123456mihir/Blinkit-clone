import React from "react";
import { createBrowserRouter } from "react-router";
import { RouterProvider } from "react-router/dom";
import Home from "./Routes/Home";
import Cart from "./Routes/Cart";

export default function App() {
     const router = createBrowserRouter(
          [
               {
                    path: "/",
                    element: <Home />,
               },
               {
                    path: "/cart",
                    element: <Cart />,
               }
          ]
     );

     return (
          <RouterProvider router={router} />
     )
}