import React from "react";

export default function MobileCartButton(){
     return(
          <div className="w=full bg-[rgb(12,131,31)] text-white rounded-xl py-2 pr-[18px] pl-3 flex items-center justify-between">
               <div></div>
               <div></div>
          </div>
     )
}