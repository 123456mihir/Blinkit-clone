import React, { Children, createContext, useState } from "react";

export const CartContext = createContext();

export default function Cart({ children }) {
     const [cart, setCart] = useState([]);

     const AddToCart = (Product) => {
          setCart((Previous) => {
               const Exisiting = Previous.find((Item) => Item.ID === Product.ID)

               if (Exisiting) {
                    return Previous.map((Item) => (Item.ID === Product.ID ? { ...Item, Quantity: Item.Quantity + 1 } : Item
                    ));
               }
               return [...Previous, { ...Product, Quantity: 1 }];
          }
          )
     }

     const RemoveFromCart = (ProductID) => {
          setCart((Previous) => {
               const Exisiting = Previous.find((Item) => Item.ID === ProductID);

               if (Exisiting?.Quantity === 1) {
                    return Previous.filter((Item) => Item.ID !== ProductID);
               }
               return Previous.map((Item) =>
                    Item.ID === ProductID ? { ...Item, Quantity: Item.Quantity - 1 } : Item
               );
          });
     };

     return (
          <>
               <CartContext.Provider value={{ cart, AddToCart, RemoveFromCart }}>
                    {children}
               </CartContext.Provider >
          </>
     )
}