const ColdDrinksAndJucices = [
     {
          ID: 51,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/2faf253a-7e5b-4d53-9774-350add8d50b5.png",
          title: "Bisleri Packaged Water (1 l)",
          quantity: "1 ltr",
          MRP: 18,
          SP: 17,
          Discount: "5%",
          DeliveryTime: "8 Mins"
     },
     {
          ID: 52,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/4345ef56-6124-4bcb-af9e-c9c2286a34fe.png",
          title: "Coca-Cola Soft Drink (750 ml) - Pack of 4",
          quantity: "4 x 750 ml",
          MRP: 159,
          SP: 160,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 53,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/6f4bd423-1666-4d23-bf3d-db482be09608.png",
          title: "Red Bull Energy Drink (250 ml)",
          quantity: "250 ml",
          SP: 125,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 54,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/d926bd74-6357-420d-841f-092197f7de2c.png",
          title: "Bisleri Packaged Water",
          quantity: "10 ltr",
          SP: 108,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 55,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/f2744d52-8878-4353-81e5-e5f17c9584b7.png",
          title: "Hell Energy Classic Energy Drink - 250ml",
          quantity: "250 ml",
          SP: 60,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 56,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/rc-upload-1770008707267-4.png",
          title: "Sprite Lime Flavored Soft Drink 750 ml",
          quantity: "750 ml",
          SP: 40,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 57,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/949aae56-99ab-42d6-ab43-862765863195.png",
          title: "Kinley Strong Soda Water",
          quantity: "750 ml",
          SP: 18,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 58,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/0c9817d0-2643-4097-98b7-7059ba21e760.png",
          title: "Coca-Cola Soft Drink (300 ml)",
          quantity: "300 ml",
          SP: 50,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 59,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/78afb4b9-c043-4640-ad07-1a38b503eb83.png",
          title: "Thums Up Soft Drink (750 ml)",
          quantity: "750 ml",
          SP: 40,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 60,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=450/da/cms-assets/cms/product/a5b7e972-ec13-4a69-a033-0d0114f42353.png",
          title: "Sting Energy Drink 250 ml",
          quantity: "250 ml",
          SP: 20,
          DeliveryTime: "8 Mins"
     }
]

export default ColdDrinksAndJucices;