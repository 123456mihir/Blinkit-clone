const SnacksAndMunchies = [
     {
          ID: 21,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/4a2d5e14-4425-4d2d-8958-6d51c6fd73d9.png",
          title: "Lo! Foods Gluten Free Ragi Chips Roasted Healthy Snacks",
          weight: "75 g",
          SP: 99,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 22,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/3eae3870-eb2a-43eb-ad30-967d17f7d691.png",
          title: "Protein Chef Baked Coated Peanuts (Masala Roasted Healthy Snacks)",
          weight: "69 g",
          MRP: 70,
          SP: 69,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 23,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/2a55bb8b-bf09-454b-9233-cc00404c6a5c.png",
          title: "Beanly Choco Hazelnut Spread with Breadsticks",
          weight: "52 g",
          MRP: 133,
          SP: 99,
          Discount: "25%",
          DeliveryTime: "8 Mins"
     },
     {
          ID: 24,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/0f6fa268-7fe7-4be5-92b7-5b98a632d370.png",
          title: "Cheetos Flamin Hot Crunchy Puffs",
          weight: "28.3 g",
          MRP: 159,
          SP: 150,
          Discount: "5%",
          DeliveryTime: "8 Mins"
     },
     {
          ID: 25,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/555c3ab0-8c4b-4837-8e59-d6ffbfbbe1f9.png",
          title: "Protein Chef Himalayan Pink Salted Peanuts (Healthy & Roasted)",
          weight: "100 g",
          SP: 49,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 26,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/ede9cc90-b8f0-4786-ada6-d40f8ba2b37c.png",
          title: "Red Rock Deli Potato Chips (Baked Olive & Greek Salad)",
          weight: "53 g",
          MRP: 60,
          SP: 51,
          Discount: "15%",
          DeliveryTime: "8 Mins"
     },
     {
          ID: 27,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/bf324463-67d9-41ce-8888-bb5c7f3cb6aa.png",
          title: "Beanly Dark Chocolate Spread with Breadsticks",
          weight: "52 g",
          MRP: 133,
          SP: 99,
          Discount: "25%",
          DeliveryTime: "8 Mins"
     },
     {
          ID: 28,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=450/da/cms-assets/cms/product/d2bb3857-4160-44f9-92f5-96a1601d283d.png",
          title: "Lay's Stax Sour Cream & Onion Potato Chips",
          weight: "155.9 g",
          SP: 350,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 29,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=450/da/cms-assets/cms/product/caef469c-2abd-4a0f-b359-f1e0475f6223.png",
          title: "Cheetos Flamin' Hot Twisted Corn Puffs",
          weight: "30 g",
          MRP: 169,
          SP: 160,
          Discount: "5%",
          DeliveryTime: "8 Mins"
     },
     {
          ID: 30,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/59bb864d-8151-457b-b6dd-9d4a2b8d1860.png",
          title: "Orion Korean Kimchi K Snack Onion Rings",
          weight: "70 g",
          SP: 48,
          MRP: 60,
          Discount: "20%",
          DeliveryTime: "8 Mins"
     }
]

export default SnacksAndMunchies;