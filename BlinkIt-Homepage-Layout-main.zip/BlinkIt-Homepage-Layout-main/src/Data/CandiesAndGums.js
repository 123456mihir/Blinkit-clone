const CandiesAndGums = [
     {
          ID: 61,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/84af17fc-39fd-44f8-ab89-69cc2bd6c2a6.png",
          title: "Alpenliebe Juzt Jelly - Strawberry Flavour Jelly Candy",
          weight: "140 g",
          MRP: 55,
          SP: 53,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 62,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/498246b3-ac58-4001-8b0f-4498d01bfd2d.png",
          title: "Kopiko Cappuccino Candy - Family Pack",
          weight: "140 g",
          MRP: 43,
          SP: 47,
          Discount: "8%",
          DeliveryTime: "8 Mins"
     },
     {
          ID: 63,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/63f3e7b4-0e07-4819-ae41-3b92cbc1d881.png",
          title: "Nestle Polo Mint Candies",
          quantity: "50 pcs",
          SP: 50,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 64,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/d4c37972-8b4d-4d65-a5e3-10cc6a0c7480.png",
          title: "Boomer Krunch Strawberry Chewing Gum",
          weight: "28.8 g",
          MRP: 45,
          SP: 43,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 65,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/63f3e7b4-0e07-4819-ae41-3b92cbc1d881.png",
          title: "Nestle Polo Mint Candies",
          quantity: "50 pcs",
          SP: 50,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 66,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/c33c2077-2019-4e33-9b12-79a9bdb8597a.png",
          title: "Parle Kismi Assorted Candy",
          weight: "245.5 g",
          MRP: 43,
          SP: 47,
          Discount: "8%",
          DeliveryTime: "8 Mins"
     },
     {
          ID: 67,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/06c51cd5-e8b4-43df-afa4-e5709bb5edbb.png",
          title: "Orbit Mixed Fruit Flavour Chewing Gum (Sugar Free)",
          weight: "19.8 g",
          SP: 45,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 68,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/7420f5a7-bd7b-4c2b-929f-d6034bb254a0.png",
          title: "Parle Poppins Candy",
          weight: "100 g",
          MRP: 28,
          SP: 24,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 79,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/5b3e5061-8ba2-44f7-a1f1-703c07d93462.png",
          title: "Wrigley's Doublemint Peppermint Chewy Mint Candies",
          weight: "27.3 g",
          SP: 45,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 70,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/ced86243-43f2-4939-8af9-98f8dd7be6ca.png",
          title: "Alpenliebe Grande with Choco Delight Eclair",
          weight: "120 g",
          MRP: 50,
          SP: 47,
          Discout: "6%",
          DeliveryTime: "8 Mins"
     }
]

export default CandiesAndGums;