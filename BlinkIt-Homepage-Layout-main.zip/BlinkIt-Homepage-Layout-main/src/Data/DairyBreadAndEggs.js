const DairyBreadAndEggs = [
     {
          ID: 1,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/7de2ccc0-3e62-43b3-81f3-2f7ad982dd25.png",
          title: "The Cinnamon Kitchen Cacao, Almond & Berry Rocks Dark Chocolate",
          weight: "50 g",
          MRP: 210,
          SP: 189,
          Discount: "10%",
          DeliveryTime: "8 Mins"
     },
     {
          ID: 2,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/bb9464ff-8ffb-4a8d-8306-cf78a2f85c80.png",
          title: "Cremeitalia Cream Cheese",
          weight: "200 g",
          MRP: 310,
          SP: 289,
          Discount: "6%",
          DeliveryTime: "8 Mins"
     },
     {
          ID: 3,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/e349c79c-9e06-444c-98aa-e69b2d505034.png",
          title: "The Cinnamon Kitchen Keto Dark Chocolate Rocks",
          weight: "50 g",
          MRP: 285,
          SP: 259,
          Discount: "9%",
          DeliveryTime: "8 Mins"
     },
     {
          ID: 4,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/b5bae482-6f9b-4853-a054-0826408d0c64.png",
          title: "The Cinnamon Kitchen Cacao, Hazelnut & Date Fudge Brownie",
          weight: "60 g (2 pieces)",
          MRP: 179,
          SP: 165,
          Discount: "7%",
          DeliveryTime: "8 Mins"
     },
     {
          ID: 5,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/3160c376-c07e-441c-afb8-195eb51a1cc4.png",
          title: "The Baker's Dozen Rich Chocolate Pound Cake",
          weight: "150 g",
          SP: 163,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 6,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/df3666bc-c07b-4a71-909a-63d829ebaed0.png",
          title: "Harvest Gold Hearty Brown Bread",
          weight: "400 g",
          SP: 55,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 7,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/628c97e0-5ed4-425d-a667-1d3bfa6f0bde.png",
          title: "Amul Gold Full Cream Milk",
          weight: "500 ml",
          SP: 34,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 8,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/1ded64a0-9f20-4a1d-8211-156f221b377b.png",
          title: "Amul Buffalo A2 Milk",
          weight: "500 ml",
          SP: 36,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 9,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/613787ac-f983-4cfb-b534-e219c8d47b39.png",
          title: "Amul Salted Butter",
          weight: "100 g",
          SP: 58,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 10,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/8f46ca37-e51e-4192-989e-0514ea0d6433.png",
          title: "Britannia Sandwich White Bread",
          weight: "600 g",
          SP: 55,
          DeliveryTime: "8 Mins"
     }
]

export default DairyBreadAndEggs;