const MouthFresheners = [
     {
          ID: 41,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/4af108c6-71f1-48ab-ba1c-77dca6c3d538.png",
          title: "Trident Original Flavour Gum (Sugar Free)",
          quantity: "14 pcs",
          SP: 150,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 42,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/bbe6e824-7332-4f55-aaf0-2e13d4057c63.png",
          title: "Pass Pass Sweet Magic Mix Mouth Freshener",
          weight: "105 g",
          SP: 105,
          MRP: 120,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 43,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/b417aadf-8504-4db2-9560-469a80461509.png",
          title: "Trident Spearmint Gum (Sugar Free)",
          quantity: "14 pcs",
          SP: 150,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 44,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/05838157-fd5d-4a44-995d-faee6f3d293e.png",
          title: "Pass Pass Sweet Magic Mix Mouth Freshener",
          weight: "105 g",
          SP: 105,
          MRP: 120,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 45,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/8a165649-9050-491d-b77f-2e652f5f47e4.png",
          title: "Rajnigandha Silver Pearl Silver Coated Elaichi Mouth Freshener",
          weight: "5.75",
          SP: 60,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 46,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=450/da/cms-assets/cms/product/b7159ab5-6b7c-4cf6-ad64-806789006144.png",
          title: "Impact Sugar Free Mint Candy (Ice Mints)",
          weight: "14 g",
          SP: 150,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 47,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=450/da/cms-assets/cms/product/b4effe01-8142-4d17-8f7b-8687230a0760.png",
          title: "Tulsi Royal Khajoor Plus",
          weight: "5 x 13 g",
          SP: 100,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 48,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=450/da/cms-assets/cms/product/4a6b9c90-e74f-4ef6-97b9-663a412e0bda.png",
          title: "Listerine Cool Mint Breath Strips Pocketpaks",
          quantity: "24 pcs",
          SP: 325,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 49,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=450/da/cms-assets/cms/product/9b7ffea9-49db-4694-b1fa-436c12508320.png",
          title: "Wrigley's 5 Peppermint Cobalt Chewing Gum (Sugar Free)",
          quantity: "15 pcs",
          SP: 244,
          MRP: 275,
          Discount: "11%",
          DeliveryTime: "8 Mins"
     },
     {
          ID: 50,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=450/da/cms-assets/cms/product/089c870b-8a15-49d0-8d58-b6d026cc4069.png",
          title: "Barkleys Wintergreen Intense Mint Candies",
          weight: "50 g",
          SP: 270,
          MRP: 300,
          Discount: "10%",
          DeliveryTime: "8 Mins"
     },
]

export default MouthFresheners;