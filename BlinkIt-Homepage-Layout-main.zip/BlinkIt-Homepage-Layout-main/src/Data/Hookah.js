const Hookah = [
     {
          ID: 31,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/0b475c4e-7593-4a75-8fcd-ea5a1ddc0c03.png",
          title: "Premium Magic Coal By Stash Pro",
          quantity: "10 pcs",
          SP: 70,
          MRP: 80,
          Discount: "12%",
          DeliveryTime: "8 Mins"
     },
     {
          ID: 32,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/8f8da451-2645-4446-b082-14adacc4a0d1.png",
          title: "Mouth Filter Tips for Filters by Afzal",
          quantity: "5 pcs",
          SP: 39,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 33,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/55cbc96f-5555-47f4-9b17-67e15a255875.png",
          title: "Instant Ignite Magic Coal by Bongchie",
          quantity: "10 pcs",
          SP: 80,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 34,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/2d829ad1-daf8-439f-aec0-2d4906ccde83.png",
          title: "Square Shape Pre-Cut Hookah Foil with Pin - Afzal",
          quantity: "1 pack",
          SP: 150,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 35,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/346b9f9b-2196-4dec-b97c-a5edc50c006c.png",
          title: "Coconut Hookah Coal by Cocoyaya",
          weight: "1 kg",
          SP: 600,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 36,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/aa46c706-33cf-45ca-97d7-cfd124484f05.png",
          title: "Magic Coal by Cocoyaya",
          quantity: "1 pack",
          SP: 70,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 37,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/55cbc96f-5555-47f4-9b17-67e15a255875.png",
          title: "Instant Ignite Magic Coal by Bongchie",
          quantity: "10 pcs",
          SP: 80,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 38,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/da/cms-assets/cms/product/33612b04-d41a-41e1-b2d3-b39d2ec4d764.png",
          title: "Hot Plate Heater Electric Coil Burner 500W by Cocoyaya",
          quantity: "1 pcs",
          SP: 690,
          DeliveryTime: "8 Mins"
     },
     {
          ID: 39,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=450/da/cms-assets/cms/product/cb4d780b-e731-4de1-a7c2-c4afb015750c.png",
          title: "Organic Mud Hookah Chillum by Smokey Lust",
          quantity: "1 pcs",
          SP: 69,
          MRP: 75,
          Discount: "8%",
          DeliveryTime: "8 Mins"
     },
     {
          ID: 40,
          src: "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=450/da/cms-assets/cms/product/eaefddd0-768f-4fe2-acaf-faef5d827730.png",
          title: "Premium Hookah Pipe by Smokey Lust",
          quantity: "1 pcs",
          SP: 299,
          MRP: 325,
          DeliveryTime: "8 Mins"
     }
]

export default Hookah;